from flask import Flask, render_template, request, redirect, session, jsonify
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'my_secret_key'


def init_db():
    conn = sqlite3.connect('all.db')
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            role TEXT DEFAULT 'student',
            fio TEXT NOT NULL,
            login TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            allergies TEXT,
            email TEXT,
            phone TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS cards (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            number TEXT NOT NULL,
            owner TEXT NOT NULL,
            amount REAL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            meal_type TEXT NOT NULL,  -- breakfast, lunch
            dish_name TEXT NOT NULL,
            portions INTEGER DEFAULT 0,
            date TEXT DEFAULT CURRENT_DATE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_name TEXT NOT NULL,
            item_type TEXT NOT NULL,  -- product, ready_dish
            quantity REAL NOT NULL,
            unit TEXT NOT NULL,
            low_stock_threshold REAL DEFAULT 5,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS purchases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_name TEXT NOT NULL,
            quantity REAL NOT NULL,
            unit TEXT NOT NULL,
            priority TEXT DEFAULT 'normal',  -- normal, urgent
            status TEXT DEFAULT 'pending',  -- pending, approved, rejected, completed
            date_needed TEXT NOT NULL,
            requested_by INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (requested_by) REFERENCES users(id)
        )
    ''')

    conn.commit()
    conn.close()
    print("✓ База данных создана!")


def get_current_user():
    if 'user_id' not in session:
        return None

    return {
        'user_id': session.get('user_id'),
        'fio': session.get('fio'),
        'login': session.get('login'),
        'role': session.get('role')
    }


# ⭐ ИНИЦИАЛИЗАЦИЯ ДАННЫХ ПРИ ПЕРВОМ ЗАПУСКЕ
def init_sample_data():
    conn = sqlite3.connect('all.db')
    cursor = conn.cursor()

    # Проверяем, есть ли уже данные
    cursor.execute('SELECT COUNT(*) FROM inventory')
    if cursor.fetchone()[0] == 0:
        # Добавляем начальные данные остатков
        sample_inventory = [
            ('Молоко', 'product', 12, 'л', 5),
            ('Яйца', 'product', 85, 'шт', 20),
            ('Гречка', 'product', 2, 'кг', 3),
            ('Куриное филе', 'product', 18, 'кг', 5),
            ('Хлеб', 'product', 7, 'буханки', 3),
            ('Завтраки', 'ready_dish', 8, 'порций', 2),
            ('Обеды', 'ready_dish', 12, 'порций', 3),
        ]
        cursor.executemany(
            'INSERT INTO inventory (item_name, item_type, quantity, unit, low_stock_threshold) VALUES (?, ?, ?, ?, ?)',
            sample_inventory
        )

    # Проверяем учёт выдачи
    cursor.execute('SELECT COUNT(*) FROM orders WHERE date = ?', (datetime.now().strftime('%Y-%m-%d'),))
    if cursor.fetchone()[0] == 0:
        # Добавляем начальные данные учёта выдачи
        sample_orders = [
            ('breakfast', 'Овсяная каша с фруктами', 42),
            ('breakfast', 'Сырники со сметаной', 42),
            ('breakfast', 'Яичница с овощами', 38),
            ('lunch', 'Борщ по-украински', 55),
            ('lunch', 'Паста Карбонара', 55),
            ('lunch', 'Котлеты по-киевски', 50),
            ('lunch', 'Салат Цезарь', 55),
            ('lunch', 'Плов узбекский', 55),
            ('lunch', 'Чизкейк Нью-Йорк', 55),
        ]
        cursor.executemany(
            'INSERT INTO orders (meal_type, dish_name, portions, date) VALUES (?, ?, ?, ?)',
            [(meal, dish, portions, datetime.now().strftime('%Y-%m-%d')) for meal, dish, portions in sample_orders]
        )

    conn.commit()
    conn.close()


@app.route('/')
def index():
    return redirect('/entr')


@app.route('/entr', methods=['GET', 'POST'])
def entr():
    if request.method == 'POST':
        return check_user()
    return render_template('entrance.html')


@app.route('/stud')
def stud():
    if 'fio' not in session:
        return redirect('/entr')
    user_fio = session['fio']
    return render_template('stud.html', fio=user_fio)


@app.route('/profstud')
def profstud():
    if 'fio' not in session:
        return redirect('/entr')
    user = get_current_user()
    return render_template('ProfileStudent.html',
                           fio=user['fio'],
                           login=user['login'],
                           role=user['role'])


@app.route('/chefprof')
def chefprof():
    if 'fio' not in session:
        return redirect('/entr')
    user_fio = session['fio']
    return render_template('index.html', fio=user_fio)


@app.route('/purch')
def purch():
    if 'fio' not in session:
        return redirect('/entr')
    user = get_current_user()
    return render_template('purchases.html', fio=user['fio'])


@app.route('/invent')
def invent():
    if 'fio' not in session:
        return redirect('/entr')
    user_fio = session['fio']
    return render_template('inventory.html', fio=user_fio)


@app.route('/order')
def order():
    if 'fio' not in session:
        return redirect('/entr')
    user_fio = session['fio']
    return render_template('orders.html', fio=user_fio)


@app.route('/adminprof')
def adminprof():
    if 'fio' not in session:
        return redirect('/entr')
    user = get_current_user()
    return render_template('adminprof.html', fio=user['fio'])


@app.route('/logout')
def logout():
    session.clear()
    return redirect('/entr')


@app.route('/api/entr', methods=['POST'])
def check_user():
    conn = sqlite3.connect('all.db')
    cursor = conn.cursor()

    data = request.get_json()
    login = data.get('login')
    password = data.get('password')

    if not login or not password:
        conn.close()
        return jsonify({
            'success': False,
            'message': '❌ Логин и пароль обязательны!'
        }), 400

    cursor.execute('SELECT * FROM users WHERE login = ? AND password = ?', (login, password))
    user = cursor.fetchone()

    conn.close()

    if user:
        session['user_id'] = user[0]
        session['role'] = user[1]
        session['fio'] = user[2]
        session['login'] = user[3]

        role = user[1]

        if role == 'student':
            redirect_url = '/stud'
        elif role == 'cook':
            redirect_url = '/chefprof'
        elif role == 'admin':
            redirect_url = '/adminprof'
        else:
            redirect_url = '/stud'

        return jsonify({
            'success': True,
            'message': f'✅ Вход выполнен, {user[2]}!',
            'redirect': redirect_url,
            'fio': user[2],
            'login': user[3],
            'role': user[1]
        }), 200
    else:
        return jsonify({
            'success': False,
            'message': '❌ Неверный логин или пароль!'
        }), 401


@app.route('/reg', methods=['GET', 'POST'])
def registrat():
    if request.method == 'GET':
        return render_template('registrat (1).html')

    conn = sqlite3.connect('all.db')
    cursor = conn.cursor()

    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'message': '❌ Нет данных в запросе'}), 400

        fio = data.get('fio', '').strip()
        login = data.get('login', '').strip()
        password = data.get('password', '').strip()
        role = data.get('role', 'student').strip()

        if not all([fio, login, password]):
            return jsonify({'success': False, 'message': '❌ Все поля обязательны!'}), 400
        if len(password) < 6:
            return jsonify({'success': False, 'message': '❌ Пароль должен быть не менее 6 символов!'}), 400
        if role not in ['student', 'cook', 'admin']:
            role = 'student'

        cursor.execute('SELECT id FROM users WHERE login = ?', (login,))
        if cursor.fetchone():
            conn.close()
            return jsonify({'success': False, 'message': '❌ Пользователь с таким логином уже существует!'}), 400

        cursor.execute('''
            INSERT INTO users (fio, login, password, role)
            VALUES (?, ?, ?, ?)
        ''', (fio, login, password, role))

        user_id = cursor.lastrowid
        conn.commit()
        conn.close()

        session['user_id'] = user_id
        session['fio'] = fio
        session['login'] = login
        session['role'] = role

        redirect_map = {
            'student': '/stud',
            'cook': '/chefprof',
            'admin': '/adminprof'
        }
        redirect_url = redirect_map.get(role, '/stud')

        return jsonify({
            'success': True,
            'message': f'✅ Регистрация успешна! Добро пожаловать, {fio}!',
            'redirect': redirect_url,
            'fio': fio,
            'login': login,
            'role': role
        }), 200

    except Exception as e:
        if 'conn' in locals():
            try:
                conn.close()
            except:
                pass
        print(f"❌ Ошибка регистрации: {e}")
        return jsonify({
            'success': False,
            'message': '❌ Критическая ошибка сервера.'
        }), 500


@app.route('/api/profstud', methods=['POST'])
def profystud():
    try:
        if 'user_id' not in session:
            return jsonify({
                'success': False,
                'message': '❌ Сессия утеряна. Пожалуйста, войдите снова.'
            }), 401

        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'message': '❌ Нет данных'}), 400

        number = data.get('cardNumber', '').strip()
        owner = data.get('cardOwner', '').strip()
        try:
            amount = float(data.get('amount', 0))
        except (TypeError, ValueError):
            return jsonify({'success': False, 'message': '❌ Некорректная сумма!'}), 400

        if not number or not owner or amount <= 0:
            return jsonify({'success': False, 'message': '❌ Заполните все поля корректно!'}), 400
        if len(number) < 4:
            return jsonify({'success': False, 'message': '❌ Номер карты слишком короткий!'}), 400

        with sqlite3.connect('all.db') as conn:
            cursor = conn.cursor()

            cursor.execute('SELECT fio FROM users WHERE id = ?', (session['user_id'],))
            user_check = cursor.fetchone()
            if not user_check:
                session.clear()
                return jsonify({
                    'success': False,
                    'message': '❌ Пользователь не найден.'
                }), 401

            cursor.execute('''
                INSERT INTO cards (user_id, number, owner, amount)
                VALUES (?, ?, ?, ?)
            ''', (session['user_id'], number, owner, amount))
            conn.commit()

        masked_number = f"{'*' * (len(number) - 4)}{number[-4:]}" if len(number) >= 4 else number

        return jsonify({
            'success': True,
            'message': f'✅ Карта {masked_number} добавлена! Баланс пополнен на {amount:.2f} ₽',
            'cardLast4': number[-4:],
            'amount': amount,
            'fio': session['fio'],
            'login': session['login']
        }), 200

    except Exception as e:
        print(f"❌ Критическая ошибка в /api/profstud: {e}")
        return jsonify({
            'success': False,
            'message': '❌ Системная ошибка.'
        }), 500

@app.route('/api/user', methods=['GET'])
def get_user_data():
    if 'user_id' not in session:
        return jsonify({
            'success': False,
            'message': '❌ Пользователь не авторизован'
        }), 401

    try:
        with sqlite3.connect('all.db') as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT id, role, fio, login, email, phone, allergies FROM users WHERE id = ?',
                           (session['user_id'],))
            user_data = cursor.fetchone()

            if not user_data:
                session.clear()
                return jsonify({
                    'success': False,
                    'message': '❌ Пользователь не найден'
                }), 401

            return jsonify({
                'success': True,
                'user': {
                    'user_id': user_data[0],
                    'role': user_data[1],
                    'fio': user_data[2],
                    'login': user_data[3],
                    'email': user_data[4] or 'Не указана',
                    'phone': user_data[5] or 'Не указан',
                    'allergies': user_data[6] or ''
                }
            }), 200

    except Exception as e:
        print(f"Ошибка получения данных: {e}")
        return jsonify({
            'success': False,
            'message': '❌ Ошибка сервера'
        }), 500


@app.route('/api/save-allergies', methods=['POST'])
def save_allergies():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': '❌ Не авторизован'}), 401

    try:
        data = request.get_json()
        allergies = data.get('allergies', '').strip()

        with sqlite3.connect('all.db') as conn:
            cursor = conn.cursor()
            cursor.execute('UPDATE users SET allergies = ? WHERE id = ?', (allergies, session['user_id']))
            conn.commit()

        return jsonify({
            'success': True,
            'message': '✅ Аллергии сохранены!'
        }), 200

    except Exception as e:
        print(f"Ошибка сохранения аллергий: {e}")
        return jsonify({
            'success': False,
            'message': '❌ Ошибка сохранения'
        }), 500


@app.route('/api/save-phone', methods=['POST'])
def save_phone():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': '❌ Не авторизован'}), 401

    try:
        data = request.get_json()
        phone = data.get('phone', '').strip()

        if not phone:
            return jsonify({'success': False, 'message': '❌ Номер телефона не может быть пустым'}), 400

        with sqlite3.connect('all.db') as conn:
            cursor = conn.cursor()
            cursor.execute('UPDATE users SET phone = ? WHERE id = ?', (phone, session['user_id']))
            conn.commit()

        return jsonify({
            'success': True,
            'message': '✅ Номер телефона сохранен!',
            'phone': phone
        }), 200

    except Exception as e:
        print(f"Ошибка сохранения телефона: {e}")
        return jsonify({
            'success': False,
            'message': '❌ Ошибка сохранения'
        }), 500


@app.route('/api/save-email', methods=['POST'])
def save_email():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': '❌ Не авторизован'}), 401

    try:
        data = request.get_json()
        email = data.get('email', '').strip()

        if not email:
            return jsonify({'success': False, 'message': '❌ Email не может быть пустым'}), 400

        if '@' not in email or '.' not in email.split('@')[1]:
            return jsonify({'success': False, 'message': '❌ Неверный формат email'}), 400

        with sqlite3.connect('all.db') as conn:
            cursor = conn.cursor()
            cursor.execute('UPDATE users SET email = ? WHERE id = ?', (email, session['user_id']))
            conn.commit()

        return jsonify({
            'success': True,
            'message': '✅ Почта сохранена!',
            'email': email
        }), 200

    except Exception as e:
        print(f"Ошибка сохранения почты: {e}")
        return jsonify({
            'success': False,
            'message': '❌ Ошибка сохранения'
        }), 500


@app.route('/api/orders', methods=['GET'])
def get_orders():
    try:
        with sqlite3.connect('all.db') as conn:
            cursor = conn.cursor()
            date = request.args.get('date', datetime.now().strftime('%Y-%m-%d'))

            cursor.execute('''
                SELECT meal_type, dish_name, portions 
                FROM orders 
                WHERE date = ?
                ORDER BY meal_type, id
            ''', (date,))

            orders = cursor.fetchall()

            breakfast = []
            lunch = []

            for order in orders:
                item = {
                    'dish_name': order[1],
                    'portions': order[2]
                }
                if order[0] == 'breakfast':
                    breakfast.append(item)
                else:
                    lunch.append(item)

            return jsonify({
                'success': True,
                'date': date,
                'breakfast': breakfast,
                'lunch': lunch
            }), 200

    except Exception as e:
        print(f"Ошибка получения учёта выдачи: {e}")
        return jsonify({
            'success': False,
            'message': '❌ Ошибка сервера'
        }), 500


@app.route('/api/orders/save', methods=['POST'])
def save_orders():
    try:
        if 'user_id' not in session:
            return jsonify({'success': False, 'message': '❌ Не авторизован'}), 401

        data = request.get_json()
        date = data.get('date', datetime.now().strftime('%Y-%m-%d'))
        breakfast = data.get('breakfast', [])
        lunch = data.get('lunch', [])

        with sqlite3.connect('all.db') as conn:
            cursor = conn.cursor()

            cursor.execute('DELETE FROM orders WHERE date = ?', (date,))

            for item in breakfast:
                cursor.execute('''
                    INSERT INTO orders (meal_type, dish_name, portions, date)
                    VALUES (?, ?, ?, ?)
                ''', ('breakfast', item['dish_name'], item['portions'], date))

            for item in lunch:
                cursor.execute('''
                    INSERT INTO orders (meal_type, dish_name, portions, date)
                    VALUES (?, ?, ?, ?)
                ''', ('lunch', item['dish_name'], item['portions'], date))

            conn.commit()

        return jsonify({
            'success': True,
            'message': '✅ Данные учёта выдачи сохранены!'
        }), 200

    except Exception as e:
        print(f"Ошибка сохранения учёта выдачи: {e}")
        return jsonify({
            'success': False,
            'message': '❌ Ошибка сохранения'
        }), 500


@app.route('/api/inventory', methods=['GET'])
def get_inventory():
    try:
        with sqlite3.connect('all.db') as conn:
            cursor = conn.cursor()

            cursor.execute('''
                SELECT item_name, quantity, unit, low_stock_threshold
                FROM inventory 
                WHERE item_type = 'product'
                ORDER BY item_name
            ''')
            products = cursor.fetchall()

            cursor.execute('''
                SELECT item_name, quantity, unit
                FROM inventory 
                WHERE item_type = 'ready_dish'
                ORDER BY item_name
            ''')
            ready_dishes = cursor.fetchall()

            return jsonify({
                'success': True,
                'products': [
                    {
                        'name': p[0],
                        'quantity': p[1],
                        'unit': p[2],
                        'low_threshold': p[3],
                        'low_stock': p[1] <= p[3]
                    }
                    for p in products
                ],
                'ready_dishes': [
                    {
                        'name': d[0],
                        'quantity': d[1],
                        'unit': d[2]
                    }
                    for d in ready_dishes
                ]
            }), 200

    except Exception as e:
        print(f"Ошибка получения остатков: {e}")
        return jsonify({
            'success': False,
            'message': '❌ Ошибка сервера'
        }), 500


@app.route('/api/inventory/update', methods=['POST'])
def update_inventory():
    try:
        if 'user_id' not in session:
            return jsonify({'success': False, 'message': '❌ Не авторизован'}), 401

        data = request.get_json()
        item_name = data.get('item_name')
        quantity = data.get('quantity')

        if not item_name or quantity is None:
            return jsonify({'success': False, 'message': '❌ Неверные данные'}), 400

        with sqlite3.connect('all.db') as conn:
            cursor = conn.cursor()

            cursor.execute('''
                UPDATE inventory 
                SET quantity = ?, updated_at = CURRENT_TIMESTAMP
                WHERE item_name = ?
            ''', (quantity, item_name))

            if cursor.rowcount == 0:
                return jsonify({'success': False, 'message': '❌ Товар не найден'}), 404

            conn.commit()

        return jsonify({
            'success': True,
            'message': '✅ Остатки обновлены!'
        }), 200

    except Exception as e:
        print(f"Ошибка обновления остатков: {e}")
        return jsonify({
            'success': False,
            'message': '❌ Ошибка обновления'
        }), 500


@app.route('/api/purchases/create', methods=['POST'])
def create_purchase():
    try:
        if 'user_id' not in session:
            return jsonify({'success': False, 'message': '❌ Не авторизован'}), 401

        data = request.get_json()
        products_text = data.get('products', '').strip()
        priority = data.get('priority', 'normal')
        date_needed = data.get('date_needed')

        if not products_text or not date_needed:
            return jsonify({'success': False, 'message': '❌ Заполните все поля'}), 400

        with sqlite3.connect('all.db') as conn:
            cursor = conn.cursor()

            products_list = products_text.split('\n')

            for product_line in products_list:
                if not product_line.strip():
                    continue
                try:
                    parts = product_line.split(',')
                    product_name = parts[0].strip()
                    qty_unit = parts[1].strip().split()
                    quantity = float(qty_unit[0])
                    unit = qty_unit[1] if len(qty_unit) > 1 else ''

                    cursor.execute('''
                        INSERT INTO purchases 
                        (product_name, quantity, unit, priority, status, date_needed, requested_by)
                        VALUES (?, ?, ?, ?, 'pending', ?, ?)
                    ''', (product_name, quantity, unit, priority, date_needed, session['user_id']))
                except Exception as e:
                    print(f"Ошибка парсинга продукта '{product_line}': {e}")
                    continue

            conn.commit()

        return jsonify({
            'success': True,
            'message': '✅ Заявка на закупку отправлена!'
        }), 200

    except Exception as e:
        print(f"Ошибка создания заявки: {e}")
        return jsonify({
            'success': False,
            'message': '❌ Ошибка создания заявки'
        }), 500


@app.route('/api/purchases', methods=['GET'])
def get_purchases():
    try:
        with sqlite3.connect('all.db') as conn:
            cursor = conn.cursor()

            cursor.execute('''
                SELECT p.id, p.product_name, p.quantity, p.unit, 
                       p.priority, p.status, p.date_needed, 
                       u.fio as requested_by_name
                FROM purchases p
                LEFT JOIN users u ON p.requested_by = u.id
                ORDER BY 
                    CASE p.status 
                        WHEN 'pending' THEN 1
                        WHEN 'approved' THEN 2
                        WHEN 'rejected' THEN 3
                        WHEN 'completed' THEN 4
                    END,
                    p.created_at DESC
            ''')

            purchases = cursor.fetchall()

            return jsonify({
                'success': True,
                'purchases': [
                    {
                        'id': p[0],
                        'product_name': p[1],
                        'quantity': p[2],
                        'unit': p[3],
                        'priority': p[4],
                        'status': p[5],
                        'date_needed': p[6],
                        'requested_by': p[7] or 'Неизвестно'
                    }
                    for p in purchases
                ]
            }), 200

    except Exception as e:
        print(f"Ошибка получения заявок: {e}")
        return jsonify({
            'success': False,
            'message': '❌ Ошибка сервера'
        }), 500


@app.route('/api/purchases/update-status', methods=['POST'])
def update_purchase_status():
    try:
        if 'user_id' not in session:
            return jsonify({'success': False, 'message': '❌ Не авторизован'}), 401

        data = request.get_json()
        purchase_id = data.get('id')
        new_status = data.get('status')

        if not purchase_id or not new_status:
            return jsonify({'success': False, 'message': '❌ Неверные данные'}), 400

        if new_status not in ['approved', 'rejected', 'completed']:
            return jsonify({'success': False, 'message': '❌ Неверный статус'}), 400

        with sqlite3.connect('all.db') as conn:
            cursor = conn.cursor()

            cursor.execute('''
                UPDATE purchases 
                SET status = ?
                WHERE id = ?
            ''', (new_status, purchase_id))

            if cursor.rowcount == 0:
                return jsonify({'success': False, 'message': '❌ Заявка не найдена'}), 404

            conn.commit()

        return jsonify({
            'success': True,
            'message': '✅ Статус заявки обновлён!'
        }), 200

    except Exception as e:
        print(f"Ошибка обновления статуса: {e}")
        return jsonify({
            'success': False,
            'message': '❌ Ошибка обновления'
        }), 500


if __name__ == '__main__':
    init_db()
    init_sample_data()
    app.run(debug=True, host='0.0.0.0', port=5000)