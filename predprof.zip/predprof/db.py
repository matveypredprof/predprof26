from app import app, db
class reg(db.Model):
    __tableName__ = 'reg'
    id = db.Column(db.Integer, primary_key=True)
    fio = db.Column(db.String(100), nullable=False)
    login = db.Column(db.String(20), nullable=False)
    password = db.Column(db.String(20), nullable=False)
    def __init__(self, fio, login, password):
        self.fio = fio
        self.login = login
        self.password = password